import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const PLATFORMS = ['TikTok','Instagram','YouTube','Facebook','Twitter/X'];
const COLORS = ['#7c3aed','#06b6d4','#ef4444','#10b981','#f59e0b','#ec4899'];

export default function Scheduler({ showToast }) {
  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [form, setForm] = useState({ title:'', platform:'TikTok', date:'', time:'', notes:'', color:COLORS[0] });
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    try { setPosts(JSON.parse(localStorage.getItem('shortai_scheduler')||'[]')); } catch {}
  }, []);

  function save(newPosts) { setPosts(newPosts); localStorage.setItem('shortai_scheduler', JSON.stringify(newPosts)); }

  function addPost() {
    if (!form.title.trim() || !form.date) { showToast('Unesi naslov i datum!','error'); return; }
    save([...posts, { ...form, id: Date.now() }]);
    setForm({ title:'', platform:'TikTok', date:'', time:'', notes:'', color:COLORS[0] });
    setShowForm(false);
    showToast('✅ Objava zakazana!','success');
  }

  function deletePost(id) { save(posts.filter(p=>p.id!==id)); showToast('🗑️ Obrisano','success'); }

  const sorted = [...posts].sort((a,b)=>new Date(a.date+' '+a.time)-new Date(b.date+' '+b.time));
  const now = new Date();

  return (
    <div>
      <div className="workspace-header">
        <button className="workspace-back" onClick={()=>navigate('/')}>← Nazad</button>
        <div className="workspace-title-row">
          <div className="workspace-icon" style={{background:'linear-gradient(135deg,rgba(6,182,212,0.2),rgba(2,132,199,0.1))'}}>📅</div>
          <h1 className="workspace-title">Social Media Scheduler</h1>
        </div>
        <p className="workspace-desc">Planiraj i zakazuj objave. Čuva se lokalno u browseru.</p>
      </div>

      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20,flexWrap:'wrap',gap:10}}>
        <p style={{color:'var(--text-secondary)',fontSize:'0.9rem'}}>{posts.length} {posts.length===1?'zakazana objava':'zakazane objave'}</p>
        <button className="btn-primary" style={{padding:'9px 18px'}} onClick={()=>setShowForm(v=>!v)}>
          {showForm?'✕ Zatvori':'+ Zakaži objavu'}
        </button>
      </div>

      {showForm && (
        <div style={{background:'var(--bg-card)',border:'1px solid var(--border-subtle)',borderRadius:'var(--radius-xl)',padding:20,marginBottom:24}}>
          <h3 style={{marginBottom:16,fontFamily:'var(--font-display)'}}>📅 Nova objava</h3>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <div className="form-group" style={{gridColumn:'1/-1'}}><label className="form-label">Naslov / Opis</label><input className="form-input" value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))} placeholder="npr. Morning routine video..." /></div>
            <div className="form-group"><label className="form-label">Platforma</label><select className="form-select" value={form.platform} onChange={e=>setForm(p=>({...p,platform:e.target.value}))}>{PLATFORMS.map(pl=><option key={pl}>{pl}</option>)}</select></div>
            <div className="form-group"><label className="form-label">Datum</label><input className="form-input" type="date" value={form.date} onChange={e=>setForm(p=>({...p,date:e.target.value}))} /></div>
            <div className="form-group"><label className="form-label">Vrijeme</label><input className="form-input" type="time" value={form.time} onChange={e=>setForm(p=>({...p,time:e.target.value}))} /></div>
            <div className="form-group"><label className="form-label">Boja oznake</label><div style={{display:'flex',gap:8,marginTop:4}}>{COLORS.map(c=><button key={c} onClick={()=>setForm(p=>({...p,color:c}))} style={{width:28,height:28,borderRadius:'50%',background:c,border:form.color===c?'3px solid #fff':'2px solid transparent',cursor:'pointer'}}/>)}</div></div>
            <div className="form-group" style={{gridColumn:'1/-1'}}><label className="form-label">Bilješke</label><textarea className="form-textarea" style={{minHeight:60}} value={form.notes} onChange={e=>setForm(p=>({...p,notes:e.target.value}))} placeholder="Hashtags, link, napomene..." /></div>
          </div>
          <button className="btn-primary" style={{width:'100%',padding:12}} onClick={addPost}>✅ Zakaži</button>
        </div>
      )}

      {!sorted.length && (
        <div className="output-placeholder"><div className="placeholder-icon">📅</div><p>Nema zakazanih objava.<br/>Dodaj prvu klikom na "Zakaži objavu".</p></div>
      )}

      <div style={{display:'flex',flexDirection:'column',gap:10}}>
        {sorted.map(post=>{
          const postDate = new Date(post.date+' '+(post.time||'00:00'));
          const isPast = postDate < now;
          return (
            <div key={post.id} style={{display:'flex',alignItems:'flex-start',gap:12,background:'var(--bg-card)',border:`1px solid var(--border-subtle)`,borderRadius:'var(--radius-lg)',padding:14,borderLeft:`4px solid ${post.color}`,opacity:isPast?0.6:1}}>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4,flexWrap:'wrap'}}>
                  <span style={{fontWeight:700,fontSize:'0.9rem'}}>{post.title}</span>
                  <span style={{padding:'2px 8px',borderRadius:'var(--radius-full)',background:post.color+'22',color:post.color,fontSize:'0.7rem',fontWeight:700}}>{post.platform}</span>
                  {isPast && <span style={{padding:'2px 8px',borderRadius:'var(--radius-full)',background:'rgba(255,255,255,0.06)',fontSize:'0.7rem',color:'var(--text-muted)'}}>✓ Prošlo</span>}
                </div>
                <div style={{fontSize:'0.78rem',color:'var(--text-muted)'}}>📅 {post.date} {post.time && `⏰ ${post.time}`}</div>
                {post.notes && <div style={{fontSize:'0.78rem',color:'var(--text-secondary)',marginTop:4}}>{post.notes}</div>}
              </div>
              <button className="btn-icon" style={{flexShrink:0}} onClick={()=>deletePost(post.id)}>🗑️</button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
