import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { callAI, callAIJSON } from '../lib/ai';
import { OutputPanel } from '../components/OutputPanel';

function Page({ icon, title, desc, iconBg, children }) {
  const navigate = useNavigate();
  return (
    <div>
      <div className="workspace-header">
        <button className="workspace-back" onClick={() => navigate('/')}>← Nazad</button>
        <div className="workspace-title-row">
          <div className="workspace-icon" style={{ background: iconBg }}>{icon}</div>
          <h1 className="workspace-title">{title}</h1>
        </div>
        <p className="workspace-desc">{desc}</p>
      </div>
      {children}
    </div>
  );
}

// ── Dialogue Generator ────────────────────────────────────────────────────────
const CHAR_TYPES = ['Stranger / Stranger','Boss / Employee','Parent / Child','Friends','Ex-partners','Rivals'];

export function Dialogue({ showToast }) {
  const navigate = useNavigate();
  const [scenario, setScenario] = useState('');
  const [charType, setCharType] = useState(CHAR_TYPES[0]);
  const [turns, setTurns] = useState('8');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!scenario.trim()) { showToast('Unesi scenario!', 'error'); return; }
    setLoading(true); setOutput('');
    await callAI(
      `You write dramatic, viral short-form video dialogues. Each line should be punchy and quotable.`,
      `Write a ${turns}-turn dialogue between ${charType} about: "${scenario}"\nFormat:\nPERSON A: ...\nPERSON B: ...\nMake it emotionally charged with a twist ending.`,
      (_, f) => setOutput(f),
      () => setLoading(false),
      err => { showToast('❌ '+err,'error'); setLoading(false); }
    );
  }

  return (
    <Page icon="🗣️" title="AI Dialogue Generator" desc="6 tipova karaktera, dramski dijalozi."
      iconBg="linear-gradient(135deg,rgba(16,185,129,0.2),rgba(6,182,212,0.1))">
      <div className="two-col">
        <div>
          <div className="form-group">
            <label className="form-label">Scenario</label>
            <textarea className="form-textarea" value={scenario} onChange={e=>setScenario(e.target.value)}
              placeholder="npr. Šef shvati da mu radnik zna tajnu..." />
          </div>
          <div className="form-group">
            <label className="form-label">Tip karaktera</label>
            <div className="chip-group">
              {CHAR_TYPES.map(c=><button key={c} className={`chip ${charType===c?'active':''}`} onClick={()=>setCharType(c)}>{c}</button>)}
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Broj izmjena</label>
            <select className="form-select" value={turns} onChange={e=>setTurns(e.target.value)}>
              {['4','6','8','12','16'].map(n=><option key={n}>{n}</option>)}
            </select>
          </div>
          <button className="btn-primary" style={{width:'100%',padding:'13px'}} onClick={generate} disabled={loading}>
            {loading?'⏳ Generišem...':'🗣️ Generiši Dijalog'}
          </button>
        </div>
        <div>
          <OutputPanel title="🗣️ Dijalog" content={output} loading={loading} />
          {output && <button className="btn-secondary" style={{marginTop:10,width:'100%'}} onClick={()=>navigate('/video-studio',{state:{script:output}})}>🎬 Video Studio</button>}
        </div>
      </div>
    </Page>
  );
}

// ── Fake Text Message ─────────────────────────────────────────────────────────
export function FakeText({ showToast }) {
  const [scenario, setScenario] = useState('');
  const [senderName, setSenderName] = useState('Sarah');
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!scenario.trim()) { showToast('Unesi scenario!','error'); return; }
    setLoading(true); setMessages([]);
    try {
      const result = await callAIJSON(
        'You generate realistic text message conversations for short videos. Return JSON only.',
        `Create a realistic text conversation for scenario: "${scenario}"\nContact name: ${senderName}\nReturn JSON: {"messages": [{"sender":"me"|"them","text":"..."},...]}\n8-12 messages, realistic and dramatic.`
      );
      setMessages(result.messages || []);
    } catch(err) {
      showToast('❌ '+err.message,'error');
    }
    setLoading(false);
  }

  return (
    <Page icon="💬" title="Fake Text Message" desc="Kreiraj lažne SMS razgovore za videe."
      iconBg="linear-gradient(135deg,rgba(6,182,212,0.2),rgba(14,165,233,0.1))">
      <div className="two-col">
        <div>
          <div className="form-group">
            <label className="form-label">Scenario razgovora</label>
            <textarea className="form-textarea" value={scenario} onChange={e=>setScenario(e.target.value)}
              placeholder="npr. Otkrijem da me partner vara, konfrontiram ih..." />
          </div>
          <div className="form-group">
            <label className="form-label">Ime kontakta</label>
            <input className="form-input" value={senderName} onChange={e=>setSenderName(e.target.value)} />
          </div>
          <button className="btn-primary" style={{width:'100%',padding:'13px'}} onClick={generate} disabled={loading}>
            {loading?'⏳ Generišem...':'💬 Generiši Poruke'}
          </button>
        </div>
        <div>
          <p className="form-label" style={{textAlign:'center',marginBottom:12}}>📱 Preview</p>
          <div className="phone-preview">
            {/* iPhone-style header */}
            <div style={{textAlign:'center',marginBottom:8,paddingBottom:8,borderBottom:'1px solid rgba(255,255,255,0.1)'}}>
              <div style={{fontSize:'0.7rem',color:'rgba(255,255,255,0.5)'}}>9:41</div>
              <div style={{fontWeight:700,fontSize:'0.9rem'}}>{senderName}</div>
            </div>
            <div className="messages-area">
              {loading && <div className="loading-spinner"><div className="spinner"/><span>Generišem...</span></div>}
              {!loading && !messages.length && <div style={{textAlign:'center',color:'rgba(255,255,255,0.3)',fontSize:'0.8rem',padding:'20px 0'}}>Poruke će se prikazati ovdje</div>}
              {messages.map((m,i)=>(
                <div key={i} className={`msg-bubble ${m.sender==='me'?'sent':'recv'}`}>{m.text}</div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Page>
  );
}

// ── TikTok Money Calculator ───────────────────────────────────────────────────
export function TikTokCalc() {
  const navigate = useNavigate();
  const [views, setViews] = useState('100000');
  const [followers, setFollowers] = useState('10000');
  const [engagementRate, setEngagementRate] = useState('5');

  const v = parseInt(views.replace(/\D/g,'')) || 0;
  const f = parseInt(followers.replace(/\D/g,'')) || 0;
  const er = parseFloat(engagementRate) || 0;

  const creatorFund = v * 0.03 / 1000;
  const brandDeal = f * (er/100) * 0.05;
  const liveGifts = f * 0.001;
  const total = creatorFund + brandDeal + liveGifts;

  function fmt(n) { return n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function fmtN(n) { return n >= 1000000 ? (n/1000000).toFixed(1)+'M' : n >= 1000 ? (n/1000).toFixed(1)+'K' : n.toString(); }

  return (
    <div>
      <div className="workspace-header">
        <button className="workspace-back" onClick={() => navigate('/')}>← Nazad</button>
        <div className="workspace-title-row">
          <div className="workspace-icon" style={{background:'linear-gradient(135deg,rgba(16,185,129,0.2),rgba(6,182,212,0.1))'}}>💰</div>
          <h1 className="workspace-title">TikTok Money Calculator</h1>
        </div>
        <p className="workspace-desc">Procjena zarade na TikTok-u bez API-ja — lokalna kalkulacija.</p>
      </div>

      <div className="two-col">
        <div>
          <div className="form-group">
            <label className="form-label">Prosječni pregledi po videu</label>
            <input className="form-input" value={views} onChange={e=>setViews(e.target.value)} placeholder="100000" />
          </div>
          <div className="form-group">
            <label className="form-label">Broj pratilaca</label>
            <input className="form-input" value={followers} onChange={e=>setFollowers(e.target.value)} placeholder="10000" />
          </div>
          <div className="form-group">
            <label className="form-label">Engagement Rate (%)</label>
            <input className="form-input" type="number" min="0" max="100" step="0.1" value={engagementRate} onChange={e=>setEngagementRate(e.target.value)} />
          </div>
        </div>

        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          {[
            {label:'Creator Fund (po videu)',val:creatorFund,icon:'🎬',desc:`${fmtN(v)} pregleda × $0.03/1K`},
            {label:'Brand Deal procjena',val:brandDeal,icon:'🤝',desc:`${fmtN(f)} pratilaca × ${er}% ER`},
            {label:'Live Gifts procjena',val:liveGifts,icon:'🎁',desc:'~$0.001 po pratiocu/mj.'},
            {label:'UKUPNO / video',val:total,icon:'💵',primary:true},
          ].map(item=>(
            <div key={item.label} style={{
              background: item.primary ? 'rgba(124,58,237,0.12)' : 'var(--bg-card)',
              border: `1px solid ${item.primary ? 'var(--accent-violet)' : 'var(--border-subtle)'}`,
              borderRadius:'var(--radius-lg)', padding:'16px'
            }}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <div>
                  <div style={{fontSize:'0.72rem',fontWeight:700,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.06em'}}>{item.icon} {item.label}</div>
                  {item.desc && <div style={{fontSize:'0.72rem',color:'var(--text-muted)',marginTop:2}}>{item.desc}</div>}
                </div>
                <div style={{
                  fontFamily:'var(--font-display)', fontWeight:800,
                  fontSize: item.primary ? '1.4rem' : '1.1rem',
                  color: item.primary ? 'var(--accent-violet-light)' : 'var(--text-primary)'
                }}>${fmt(item.val)}</div>
              </div>
            </div>
          ))}
          <div style={{fontSize:'0.72rem',color:'var(--text-muted)',padding:'8px 4px',lineHeight:1.6}}>
            ⚠️ Ovo su procjene. Stvarna zarada zavisi od tržišta, sezone i ugovora s brendovima.
          </div>
        </div>
      </div>
    </div>
  );
}
