import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { callAI } from '../lib/ai';
import { OutputPanel } from '../components/OutputPanel';

// ── Shared WorkspacePage wrapper ──────────────────────────────────────────────
function Page({ icon, title, desc, iconBg, children }) {
  const navigate = useNavigate();
  return (
    <div>
      <div className="workspace-header">
        <button className="workspace-back" onClick={() => navigate('/')}>← Nazad</button>
        <div className="workspace-title-row">
          <div className="workspace-icon" style={{ background: iconBg }}>{icon}</div>
          <h1 className="workspace-title">{title}</h1>
        </div>
        <p className="workspace-desc">{desc}</p>
      </div>
      {children}
    </div>
  );
}

// ── Script Generator ──────────────────────────────────────────────────────────
const SG_TEMPLATES = ['Hook + Story + CTA','Problem → Solution','Listicle (Top 5)','Before & After','Controversy / Hot Take','POV Story','Tutorial Step-by-step','Product Review'];

export function ScriptGen({ showToast }) {
  const navigate = useNavigate();
  const [topic, setTopic] = useState('');
  const [template, setTemplate] = useState(SG_TEMPLATES[0]);
  const [platform, setPlatform] = useState('TikTok');
  const [duration, setDuration] = useState('60 sekundi');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!topic.trim()) { showToast('Unesi temu!', 'error'); return; }
    setLoading(true); setOutput('');
    await callAI(
      `You are a viral ${platform} script writer. Create highly engaging scripts.`,
      `Write a ${duration} ${platform} script about "${topic}" using the "${template}" format.\nInclude [HOOK], scene labels, [CTA]. Make it scroll-stopping.`,
      (_, f) => setOutput(f),
      () => setLoading(false),
      err => { showToast('❌ '+err, 'error'); setLoading(false); }
    );
  }

  return (
    <Page icon="📝" title="Script Generator" desc="8 viral template-a za kratke skripte."
      iconBg="linear-gradient(135deg,rgba(245,158,11,0.2),rgba(239,68,68,0.1))">
      <div className="two-col">
        <div>
          <div className="form-group">
            <label className="form-label">Tema / Proizvod</label>
            <textarea className="form-textarea" value={topic} onChange={e=>setTopic(e.target.value)}
              placeholder="npr. Morning routine koji mi je promijenio život..." />
          </div>
          <div className="form-group">
            <label className="form-label">Template</label>
            <div className="chip-group">
              {SG_TEMPLATES.map(t=><button key={t} className={`chip ${template===t?'active':''}`} onClick={()=>setTemplate(t)}>{t}</button>)}
            </div>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <div className="form-group">
              <label className="form-label">Platforma</label>
              <select className="form-select" value={platform} onChange={e=>setPlatform(e.target.value)}>
                {['TikTok','Instagram Reels','YouTube Shorts','Facebook'].map(p=><option key={p}>{p}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Trajanje</label>
              <select className="form-select" value={duration} onChange={e=>setDuration(e.target.value)}>
                {['30 sekundi','60 sekundi','90 sekundi','3 minute'].map(d=><option key={d}>{d}</option>)}
              </select>
            </div>
          </div>
          <button className="btn-primary" style={{width:'100%',padding:'13px'}} onClick={generate} disabled={loading}>
            {loading?'⏳ Generišem...':'📝 Generiši Skriptu'}
          </button>
        </div>
        <div>
          <OutputPanel title="📝 Skripta" content={output} loading={loading} />
          {output && <button className="btn-secondary" style={{marginTop:10,width:'100%'}} onClick={()=>navigate('/video-studio',{state:{script:output}})}>🎬 Video Studio</button>}
        </div>
      </div>
    </Page>
  );
}

// ── Reddit Story ──────────────────────────────────────────────────────────────
const SUBREDDITS = ['r/AITA','r/relationship_advice','r/tifu','r/prorevenge','r/pettyrevenge','r/confessions','r/TrueOffMyChest'];

export function RedditStory({ showToast }) {
  const navigate = useNavigate();
  const [topic, setTopic] = useState('');
  const [sub, setSub] = useState('r/AITA');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!topic.trim()) { showToast('Unesi situaciju!', 'error'); return; }
    setLoading(true); setOutput('');
    await callAI(
      `You write viral Reddit-style stories for short video narration. Match the ${sub} community tone exactly.`,
      `Write a ${sub} post about: "${topic}"\nMake it realistic, emotionally engaging, with a twist. Start with "So..." or "UPDATE:" style opening. Include votes, edit notes.`,
      (_, f) => setOutput(f),
      () => setLoading(false),
      err => { showToast('❌ '+err,'error'); setLoading(false); }
    );
  }

  return (
    <Page icon="😱" title="Reddit Story Generator" desc="AITA, r/stories i ostali Reddit formati."
      iconBg="linear-gradient(135deg,rgba(255,69,0,0.2),rgba(255,107,53,0.1))">
      <div className="two-col">
        <div>
          <div className="form-group">
            <label className="form-label">Situacija</label>
            <textarea className="form-textarea" value={topic} onChange={e=>setTopic(e.target.value)}
              placeholder="npr. Otkazao sam vjencanje jer sam saznao tajnu..." />
          </div>
          <div className="form-group">
            <label className="form-label">Subreddit</label>
            <div className="chip-group">
              {SUBREDDITS.map(s=><button key={s} className={`chip ${sub===s?'active':''}`} onClick={()=>setSub(s)}>{s}</button>)}
            </div>
          </div>
          <button className="btn-primary" style={{width:'100%',padding:'13px'}} onClick={generate} disabled={loading}>
            {loading?'⏳ Generišem...':'😱 Generiši Reddit Post'}
          </button>
        </div>
        <div>
          <OutputPanel title="👾 Reddit Story" content={output} loading={loading} />
          {output && <button className="btn-secondary" style={{marginTop:10,width:'100%'}} onClick={()=>navigate('/video-studio',{state:{script:output}})}>🎬 Video Studio</button>}
        </div>
      </div>
    </Page>
  );
}

// ── Caption Generator ─────────────────────────────────────────────────────────
export function Captions({ showToast }) {
  const [topic, setTopic] = useState('');
  const [platform, setPlatform] = useState('TikTok');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!topic.trim()) { showToast('Unesi temu!','error'); return; }
    setLoading(true); setOutput('');
    await callAI(
      `You write viral social media captions optimized for ${platform}.`,
      `Write 3 different captions for a ${platform} post about: "${topic}"\nEach caption: different tone (hype, emotional, controversial).\nInclude relevant emojis and hashtags.`,
      (_, f) => setOutput(f),
      () => setLoading(false),
      err => { showToast('❌ '+err,'error'); setLoading(false); }
    );
  }

  return (
    <Page icon="✍️" title="Caption Generator" desc="3 platformski optimizovana captiona."
      iconBg="linear-gradient(135deg,rgba(236,72,153,0.2),rgba(244,63,94,0.1))">
      <div className="two-col">
        <div>
          <div className="form-group">
            <label className="form-label">Tema / O čemu je video</label>
            <textarea className="form-textarea" value={topic} onChange={e=>setTopic(e.target.value)}
              placeholder="npr. Moj morning routine koji mi je promijenio produktivnost..." />
          </div>
          <div className="form-group">
            <label className="form-label">Platforma</label>
            <div className="chip-group">
              {['TikTok','Instagram','YouTube Shorts','LinkedIn'].map(p=><button key={p} className={`chip ${platform===p?'active':''}`} onClick={()=>setPlatform(p)}>{p}</button>)}
            </div>
          </div>
          <button className="btn-primary" style={{width:'100%',padding:'13px'}} onClick={generate} disabled={loading}>
            {loading?'⏳ Generišem...':'✍️ Generiši Caption'}
          </button>
        </div>
        <div><OutputPanel title="✍️ Captioni" content={output} loading={loading} /></div>
      </div>
    </Page>
  );
}

// ── Video Ideas ───────────────────────────────────────────────────────────────
export function VideoIdeas({ showToast }) {
  const [niche, setNiche] = useState('');
  const [platform, setPlatform] = useState('TikTok');
  const [count, setCount] = useState('10');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!niche.trim()) { showToast('Unesi nišu!','error'); return; }
    setLoading(true); setOutput('');
    await callAI(
      `You are a viral content strategist for ${platform}. Generate video ideas that get millions of views.`,
      `Generate ${count} viral video ideas for niche: "${niche}" on ${platform}.\nFor each idea include: Title, Hook (first 3 seconds), Why it'll go viral.\nFormat as numbered list.`,
      (_, f) => setOutput(f),
      () => setLoading(false),
      err => { showToast('❌ '+err,'error'); setLoading(false); }
    );
  }

  return (
    <Page icon="💡" title="Video Ideas Generator" desc="Ideje za videe prilagođene tvojoj niši."
      iconBg="linear-gradient(135deg,rgba(245,158,11,0.2),rgba(251,191,36,0.1))">
      <div className="two-col">
        <div>
          <div className="form-group">
            <label className="form-label">Tvoja niša / kanal</label>
            <input className="form-input" value={niche} onChange={e=>setNiche(e.target.value)}
              placeholder="npr. fitness, finance, relationship advice, cooking..." />
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <div className="form-group">
              <label className="form-label">Platforma</label>
              <select className="form-select" value={platform} onChange={e=>setPlatform(e.target.value)}>
                {['TikTok','Instagram Reels','YouTube Shorts','YouTube'].map(p=><option key={p}>{p}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Broj ideja</label>
              <select className="form-select" value={count} onChange={e=>setCount(e.target.value)}>
                {['5','10','20'].map(n=><option key={n}>{n}</option>)}
              </select>
            </div>
          </div>
          <button className="btn-primary" style={{width:'100%',padding:'13px'}} onClick={generate} disabled={loading}>
            {loading?'⏳ Generišem...':'💡 Generiši Ideje'}
          </button>
        </div>
        <div><OutputPanel title="💡 Video Ideje" content={output} loading={loading} /></div>
      </div>
    </Page>
  );
}

// ── Subtitle Generator ────────────────────────────────────────────────────────
const SUB_STYLES = ['Hormozi (Bold/Caps)','TikTok Default','Word-by-Word','Karaoke Style'];

export function Subtitles({ showToast }) {
  const [text, setText] = useState('');
  const [style, setStyle] = useState(SUB_STYLES[0]);
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!text.trim()) { showToast('Unesi tekst!','error'); return; }
    setLoading(true); setOutput('');
    await callAI(
      `You format video subtitles in the "${style}" style for short-form video.`,
      `Format these words as "${style}" subtitles:\n\n${text}\n\nBreak into short caption segments (2-5 words each). Add timing markers [00:00]. Capitalize for impact where appropriate.`,
      (_, f) => setOutput(f),
      () => setLoading(false),
      err => { showToast('❌ '+err,'error'); setLoading(false); }
    );
  }

  return (
    <Page icon="📺" title="Subtitle Generator" desc="Hormozi, TikTok i ostali caption stilovi."
      iconBg="linear-gradient(135deg,rgba(124,58,237,0.2),rgba(6,182,212,0.1))">
      <div className="two-col">
        <div>
          <div className="form-group">
            <label className="form-label">Tekst / Transkript</label>
            <textarea className="form-textarea" style={{minHeight:160}} value={text} onChange={e=>setText(e.target.value)}
              placeholder="Zalijepi tekst koji želiš formatirati kao titlove..." />
          </div>
          <div className="form-group">
            <label className="form-label">Stil</label>
            <div className="chip-group">
              {SUB_STYLES.map(s=><button key={s} className={`chip ${style===s?'active':''}`} onClick={()=>setStyle(s)}>{s}</button>)}
            </div>
          </div>
          <button className="btn-primary" style={{width:'100%',padding:'13px'}} onClick={generate} disabled={loading}>
            {loading?'⏳ Generišem...':'📺 Generiši Titlove'}
          </button>
        </div>
        <div><OutputPanel title="📺 Titlovi" content={output} loading={loading} /></div>
      </div>
    </Page>
  );
}
