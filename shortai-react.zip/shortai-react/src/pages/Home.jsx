import { useNavigate } from 'react-router-dom';

const TOOLS = [
  { id: 'ai-story',       icon: '📖', title: 'AI Story Generator',      desc: 'Generiši virusne priče za kratke videe.', badge: 'hot', color: '#7c3aed,#ec4899' },
  { id: 'reddit-story',   icon: '😱', title: 'Reddit Story Generator',   desc: 'AITA, r/stories i ostali Reddit formati.', color: '#ff4500,#ff6b35' },
  { id: 'fake-text',      icon: '💬', title: 'Fake Text Message',        desc: 'Kreiraj lažne SMS razgovore za videe.', badge: 'hot', color: '#06b6d4,#0ea5e9' },
  { id: 'dialogue',       icon: '🗣️', title: 'AI Dialogue Generator',    desc: '6 tipova karaktera, dramski dijalozi.', color: '#10b981,#06b6d4' },
  { id: 'script-gen',     icon: '📝', title: 'Script Generator',         desc: '8 viral template-a za kratke skripte.', color: '#f59e0b,#ef4444' },
  { id: 'subtitles',      icon: '📺', title: 'Subtitle Generator',       desc: 'Hormozi, TikTok i ostali caption stilovi.', color: '#7c3aed,#06b6d4' },
  { id: 'tiktok-calc',    icon: '💰', title: 'TikTok Money Calculator',  desc: 'Izračunaj zaradu bez API-ja.', badge: 'free', color: '#10b981,#06b6d4' },
  { id: 'captions',       icon: '✍️', title: 'Caption Generator',        desc: '3 platformski optimizovana captiona.', color: '#ec4899,#f43f5e' },
  { id: 'video-ideas',    icon: '💡', title: 'Video Ideas Generator',    desc: 'Ideje za videe prilagođene tvojoj niši.', color: '#f59e0b,#fbbf24' },
  { id: 'scheduler',      icon: '📅', title: 'Social Media Scheduler',   desc: 'Kalendar objava, lokalni storage.', color: '#06b6d4,#0284c7' },
  { id: 'video-studio',   icon: '🎬', title: 'Video Studio',             desc: 'Pretvori skriptu u video. Upload na YT/TikTok/IG.', badge: 'new', color: '#7c3aed,#06b6d4' },
  { id: 'video-inspector',icon: '🔍', title: 'Video Kloner',             desc: 'Analiziraj YT/TikTok/IG video → kloniraj ideju.', badge: 'new', color: '#06b6d4,#7c3aed' },
];

const BADGE_STYLES = {
  hot:  'badge-hot',
  free: 'badge-free',
  new:  'badge-new',
};

export default function Home() {
  const navigate = useNavigate();
  return (
    <div>
      {/* Hero */}
      <div className="hero">
        <div className="hero-eyebrow">⚡ 12 AI Alata · Besplatno · Bez registracije</div>
        <h1>
          Kreiraj virusni sadržaj<br />
          <span className="hero-gradient">za kratke videe</span>
        </h1>
        <p className="hero-sub">
          AI alati za skripte, videe, captione i upload. Podrška za Groq, Claude, GPT i OpenRouter.
        </p>
      </div>

      {/* Grid */}
      <div className="tools-grid">
        {TOOLS.map(tool => (
          <article
            key={tool.id}
            className="tool-card"
            onClick={() => navigate(`/${tool.id}`)}
          >
            {tool.badge && (
              <div className={`badge ${BADGE_STYLES[tool.badge]} tool-card-badge`}>
                {tool.badge === 'new' ? '🆕 Novo' : tool.badge === 'hot' ? '🔥 Hot' : '✅ Besplatno'}
              </div>
            )}
            <div className="tool-card-icon"
              style={{ background: `linear-gradient(135deg,rgba(${hexToRgb(tool.color.split(',')[0])},0.2),rgba(${hexToRgb(tool.color.split(',')[1])},0.1))` }}>
              {tool.icon}
            </div>
            <div>
              <h3 className="tool-card-title">{tool.title}</h3>
              <p className="tool-card-desc">{tool.desc}</p>
            </div>
            <div className="tool-card-arrow">Otvori →</div>
          </article>
        ))}
      </div>
    </div>
  );
}

function hexToRgb(hex) {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0,2),16);
  const g = parseInt(h.slice(2,4),16);
  const b = parseInt(h.slice(4,6),16);
  return `${r},${g},${b}`;
}
