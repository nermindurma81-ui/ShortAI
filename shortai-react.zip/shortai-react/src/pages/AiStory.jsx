import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { callAI } from '../lib/ai';
import { OutputPanel } from '../components/OutputPanel';

const GENRES = ['Horror','Drama','Komično','Romantično','Thriller','Mystery','Sci-Fi','True Crime'];
const DURATIONS = ['30 sekundi','60 sekundi','90 sekundi','3 minute'];
const TONES = ['Dramatično','Emocionalno','Uzbudljivo','Mračno','Inspirativno','Smiješno'];

export default function AiStory({ showToast }) {
  const navigate = useNavigate();
  const [topic, setTopic] = useState('');
  const [genre, setGenre] = useState('Horror');
  const [duration, setDuration] = useState('60 sekundi');
  const [tone, setTone] = useState('Dramatično');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!topic.trim()) { showToast('Unesi temu priče!','error'); return; }
    setLoading(true); setOutput('');
    await callAI(
      `You are a viral short-form video story writer. Write engaging ${genre} stories optimized for ${duration} videos.`,
      `Write a ${tone} ${genre} story about: "${topic}"\nDuration: ${duration}\nFormat: [HOOK] opening + [SCENES] + [ENDING]\nMake it gripping and shareable.`,
      (_, full) => setOutput(full),
      () => setLoading(false),
      err => { showToast('❌ '+err,'error'); setLoading(false); }
    );
  }

  return (
    <div>
      <div className="workspace-header">
        <button className="workspace-back" onClick={() => navigate('/')}>← Nazad</button>
        <div className="workspace-title-row">
          <div className="workspace-icon" style={{background:'linear-gradient(135deg,rgba(124,58,237,0.2),rgba(236,72,153,0.1))'}}>📖</div>
          <h1 className="workspace-title">AI Story Generator</h1>
        </div>
        <p className="workspace-desc">Generiši virusne priče za kratke videe.</p>
      </div>

      <div className="two-col">
        <div>
          <div className="form-group">
            <label className="form-label">Tema priče</label>
            <textarea className="form-textarea" value={topic} onChange={e=>setTopic(e.target.value)}
              placeholder="npr. Žena koja otkrije da joj muž ima tajni život..." />
          </div>
          <div className="form-group">
            <label className="form-label">Žanr</label>
            <div className="chip-group">
              {GENRES.map(g=><button key={g} className={`chip ${genre===g?'active':''}`} onClick={()=>setGenre(g)}>{g}</button>)}
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Trajanje</label>
            <div className="chip-group">
              {DURATIONS.map(d=><button key={d} className={`chip ${duration===d?'active':''}`} onClick={()=>setDuration(d)}>{d}</button>)}
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Ton</label>
            <div className="chip-group">
              {TONES.map(t=><button key={t} className={`chip ${tone===t?'active':''}`} onClick={()=>setTone(t)}>{t}</button>)}
            </div>
          </div>
          <button className="btn-primary" style={{width:'100%',padding:'13px'}} onClick={generate} disabled={loading}>
            {loading ? '⏳ Generišem...' : '✨ Generiši Priču'}
          </button>
        </div>
        <div>
          <OutputPanel id="story-output" title="📖 Generisana Priča" content={output} loading={loading}
            placeholder="Unesi temu i klikni Generiši." />
          {output && (
            <button className="btn-secondary" style={{marginTop:10,width:'100%'}}
              onClick={()=>{ navigate('/video-studio', {state:{script:output}}); }}>
              🎬 Pošalji u Video Studio
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
