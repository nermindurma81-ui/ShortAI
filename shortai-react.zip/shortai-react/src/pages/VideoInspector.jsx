import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { callAI, callAIJSON } from '../lib/ai';

function detectPlatform(url) {
  if (/youtube\.com|youtu\.be/i.test(url)) return { name: 'YouTube', icon: '▶️' };
  if (/tiktok\.com/i.test(url)) return { name: 'TikTok', icon: '🎵' };
  if (/instagram\.com/i.test(url)) return { name: 'Instagram', icon: '📸' };
  if (/twitter\.com|x\.com/i.test(url)) return { name: 'Twitter/X', icon: '🐦' };
  return { name: 'Web Video', icon: '🌐' };
}

const CLONE_TYPES = [
  { val:'same',     icon:'🪞', label:'Kloniraj Identično', desc:'Isti format, nova skripta' },
  { val:'improved', icon:'⬆️', label:'Poboljšana Verzija',  desc:'Jači hook, bolji ending' },
  { val:'remixed',  icon:'🎲', label:'Remix / Twist',       desc:'Novi ugao iste teme' },
  { val:'series',   icon:'📚', label:'Napravi Seriju',      desc:'5 videa na istu temu' },
  { val:'localize', icon:'🌍', label:'Lokalizuj',           desc:'Adaptiraj za Balkanske gledaoce' },
];

const DOWNLOADERS = [
  { id:'cobalt',   icon:'🔵', name:'Cobalt Tools',  desc:'Najpopularniji, open source, bez reklama', url:'https://cobalt.tools/' },
  { id:'savefrom', icon:'🟡', name:'SaveFrom.net',  desc:'YouTube + Facebook + Instagram, do 1080p', url:'https://savefrom.net/' },
  { id:'snapsave', icon:'📸', name:'SnapSave.app',  desc:'TikTok i Instagram bez watermark-a',       url:'https://snapsave.app/' },
  { id:'y2mate',   icon:'▶️', name:'Y2Mate',        desc:'YouTube do 4K, MP4 i MP3',                 url:'https://www.y2mate.com/' },
];

export default function VideoInspector({ showToast }) {
  const navigate = useNavigate();
  const [url, setUrl] = useState('');
  const [platform, setPlatform] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [cloneOutput, setCloneOutput] = useState('');
  const [cloneTitle, setCloneTitle] = useState('');
  const [cloneLoading, setCloneLoading] = useState(false);
  const [showDownloaders, setShowDownloaders] = useState(false);
  const [lastType, setLastType] = useState('same');

  async function analyze() {
    const trimmed = url.trim();
    if (!trimmed) { showToast('Unesi URL!','error'); return; }
    try { new URL(trimmed); } catch { showToast('Nevažeći URL','error'); return; }
    const p = detectPlatform(trimmed);
    setPlatform(p); setLoading(true); setAnalysis(null); setCloneOutput('');
    try {
      const result = await callAIJSON(
        'You analyze social media video URLs and infer content strategy. Return JSON only.',
        `Analyze this ${p.name} video URL and infer the content strategy:\nURL: ${trimmed}\n\nReturn JSON:\n{"topic":"...","niche":"...","format":"...","estimated_duration":"...","visual_style":"...","hook_strategy":"...","target_audience":"...","viral_elements":["..."],"keywords":["..."],"suggested_twist":"..."}`
      );
      setAnalysis(result);
      showToast('✅ Analiza gotova!','success');
    } catch(err) { showToast('❌ '+err.message,'error'); }
    setLoading(false);
  }

  async function cloneScript(type) {
    if (!analysis) { showToast('Analiziraj video prvo!','error'); return; }
    setLastType(type);
    const info = CLONE_TYPES.find(c=>c.val===type);
    setCloneTitle(info?.label||'Klonirana Skripta');
    setCloneLoading(true); setCloneOutput('');
    const a = analysis;
    const prompts = {
      same:     `Create a viral short video script that clones this strategy:\nTopic: ${a.topic}\nFormat: ${a.format} in niche: ${a.niche}\nHook: ${a.hook_strategy}\nWrite a complete new script in the same format. Include [HOOK][SCENES][CTA].`,
      improved: `Create an IMPROVED version:\nTopic: ${a.topic}\nFormat: ${a.format}\nOriginal hook: ${a.hook_strategy}\nTwist: ${a.suggested_twist||'more emotional'}\nWrite a script with a STRONGER hook and better ending. Include [HOOK][TWIST][CTA].`,
      remixed:  `Create a REMIXED version with a different angle:\nTopic: ${a.topic}\nApproach the same topic from a contrarian or surprising angle. Use a completely different format. Include [HOOK][UNEXPECTED][CTA].`,
      series:   `Create a 5-VIDEO SERIES:\nTopic: ${a.topic}\nNiche: ${a.niche}\nFor each video: VIDEO N: [title + 3-sentence outline + hook]. Make each standalone but part of a series.`,
      localize: `LOKALIZUJ za Balkanske gledaoce (BiH, Srbija, Hrvatska):\nOriginal: ${a.topic}\nAdaptiraj sa lokalnim referencama, cijenama, mjestima. Napiši kompletnu skriptu na Bosanskom jeziku.`,
    };
    await callAI(
      'You write viral short video scripts.',
      prompts[type]||prompts.same,
      (_,f)=>setCloneOutput(f),
      ()=>setCloneLoading(false),
      err=>{ showToast('❌ '+err,'error'); setCloneLoading(false); }
    );
  }

  return (
    <div>
      <div className="workspace-header">
        <button className="workspace-back" onClick={()=>navigate('/')}>← Nazad</button>
        <div className="workspace-title-row">
          <div className="workspace-icon" style={{background:'linear-gradient(135deg,rgba(6,182,212,0.2),rgba(124,58,237,0.15))'}}>🔍</div>
          <h1 className="workspace-title">Video Inspektor & Kloner</h1>
        </div>
        <p className="workspace-desc">Analiziraj YT/TikTok/IG video → AI klonira ideju, stil i strukturu → generiši vlastiti video.</p>
      </div>

      {/* URL Input */}
      <div className="form-group">
        <label className="form-label">URL videa (YouTube / TikTok / Instagram / Twitter)</label>
        <div style={{display:'flex',gap:10}}>
          <input className="form-input" value={url} onChange={e=>setUrl(e.target.value)}
            placeholder="https://www.youtube.com/watch?v=..." style={{flex:1}}
            onKeyDown={e=>e.key==='Enter'&&analyze()} />
          <button className="btn-primary" style={{flexShrink:0,padding:'11px 18px'}} onClick={analyze} disabled={loading}>
            {loading?'⏳':'🔍 Analiziraj'}
          </button>
        </div>
        {platform && (
          <div style={{display:'flex',alignItems:'center',gap:8,marginTop:10,padding:'6px 14px',borderRadius:'var(--radius-full)',background:'rgba(124,58,237,0.1)',border:'1px solid var(--border-subtle)',width:'fit-content',fontSize:'0.78rem',fontWeight:700}}>
            <span>{platform.icon}</span><span>{platform.name} detektovan</span>
          </div>
        )}
      </div>

      {loading && <div className="loading-spinner"><div className="spinner"/><span>AI analizira video strategiju...</span></div>}

      {!loading && !analysis && (
        <div className="output-placeholder" style={{minHeight:220}}>
          <div className="placeholder-icon">🔍</div>
          <p style={{maxWidth:320,margin:'0 auto',textAlign:'center'}}>Zalijepi URL bilo kojeg YouTube, TikTok ili Instagram videa.<br/><br/>AI analizira temu, format i hook strategiju — bez preuzimanja videa.</p>
        </div>
      )}

      {analysis && !loading && (
        <div>
          {/* Analysis cards */}
          <div className="analysis-grid">
            <div className="analysis-card"><div style={{fontSize:'0.72rem',fontWeight:700,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:8}}>🎯 Tema & Niša</div><div style={{fontSize:'0.9rem'}}>{analysis.topic}</div></div>
            <div className="analysis-card"><div style={{fontSize:'0.72rem',fontWeight:700,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:8}}>🎭 Format</div><div style={{fontSize:'0.9rem'}}>{analysis.format} · {analysis.niche}</div></div>
            <div className="analysis-card"><div style={{fontSize:'0.72rem',fontWeight:700,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:8}}>⏱️ Trajanje</div><div style={{fontSize:'0.9rem'}}>{analysis.estimated_duration}</div></div>
            <div className="analysis-card"><div style={{fontSize:'0.72rem',fontWeight:700,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:8}}>🎨 Vizualni stil</div><div style={{fontSize:'0.9rem'}}>{analysis.visual_style}</div></div>
            <div className="analysis-card" style={{gridColumn:'1/-1'}}><div style={{fontSize:'0.72rem',fontWeight:700,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:8}}>🪝 Hook Strategija</div><div style={{fontSize:'0.9rem'}}>{analysis.hook_strategy}</div></div>
            <div className="analysis-card" style={{gridColumn:'1/-1'}}>
              <div style={{fontSize:'0.72rem',fontWeight:700,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:8}}>🔖 Keywords</div>
              <div className="analysis-card-tags">{[...(analysis.keywords||[]),...(analysis.viral_elements||[])].map((t,i)=><span key={i} className="analysis-card-tag">{t}</span>)}</div>
            </div>
          </div>

          {/* Clone Actions */}
          <div className="form-group">
            <label className="form-label" style={{marginBottom:12}}>⚡ Šta želiš uraditi?</label>
            <div className="clone-actions">
              {CLONE_TYPES.map(c=>(
                <div key={c.val} className="clone-action-btn" onClick={()=>cloneScript(c.val)}>
                  <div style={{fontSize:'1.5rem'}}>{c.icon}</div>
                  <div style={{fontSize:'0.78rem',fontWeight:700}}>{c.label}</div>
                  <div style={{fontSize:'0.67rem',color:'var(--text-muted)'}}>{c.desc}</div>
                </div>
              ))}
              <div className="clone-action-btn" onClick={()=>setShowDownloaders(v=>!v)}>
                <div style={{fontSize:'1.5rem'}}>⬇️</div>
                <div style={{fontSize:'0.78rem',fontWeight:700}}>Preuzmi Original</div>
                <div style={{fontSize:'0.67rem',color:'var(--text-muted)'}}>Besplatni downloaderji</div>
              </div>
            </div>
          </div>

          {/* Downloaders */}
          {showDownloaders && (
            <div style={{background:'var(--bg-card)',border:'1px solid var(--border-subtle)',borderRadius:'var(--radius-xl)',padding:20,marginBottom:20}}>
              <p className="form-label" style={{marginBottom:12}}>⬇️ Besplatni video downloaderji</p>
              <p style={{fontSize:'0.8rem',color:'var(--text-muted)',marginBottom:14,lineHeight:1.5}}>⚠️ Preuzimaj samo videe za koje imaš dozvolu ili za ličnu upotrebu.</p>
              {DOWNLOADERS.map(d=>(
                <div key={d.id} onClick={()=>window.open(d.url,'_blank')} style={{display:'flex',alignItems:'center',gap:12,padding:12,borderRadius:'var(--radius-md)',border:'1px solid var(--border-subtle)',marginBottom:8,cursor:'pointer',background:'var(--bg-elevated)',transition:'all var(--transition-fast)'}}>
                  <span style={{fontSize:'1.4rem'}}>{d.icon}</span>
                  <div style={{flex:1}}><div style={{fontSize:'0.85rem',fontWeight:700}}>{d.name}</div><div style={{fontSize:'0.72rem',color:'var(--text-muted)'}}>{d.desc}</div></div>
                  <span style={{color:'var(--text-muted)'}}>→</span>
                </div>
              ))}
              <div style={{marginTop:12,background:'rgba(16,185,129,0.06)',border:'1px solid rgba(16,185,129,0.2)',borderRadius:'var(--radius-md)',padding:12,fontSize:'0.8rem',color:'var(--text-secondary)'}}>
                💡 Nakon preuzimanja idi u <strong>Video Studio → Biblioteka → Upload</strong>
              </div>
            </div>
          )}

          {/* Clone output */}
          {(cloneLoading || cloneOutput) && (
            <div className="output-panel">
              <div className="output-header">
                <div className="output-title">{cloneTitle}</div>
                <div className="output-actions">
                  <button className="btn-icon" onClick={()=>navigator.clipboard.writeText(cloneOutput)} title="Kopiraj">📋</button>
                  <button className="btn-icon" onClick={()=>{ if(cloneOutput){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([cloneOutput],{type:'text/plain'}));a.download='klonirana-skripta.txt';a.click();}}} title="Download">⬇️</button>
                </div>
              </div>
              <div className="output-body">
                {cloneLoading && <div className="loading-spinner"><div className="spinner"/><span>Kloniram video strategiju...</span></div>}
                {cloneOutput && <pre className="output-text">{cloneOutput}</pre>}
              </div>
              {cloneOutput && (
                <div style={{padding:'12px 20px',borderTop:'1px solid var(--border-subtle)',display:'flex',gap:8,flexWrap:'wrap'}}>
                  <button className="btn-primary" style={{fontSize:'0.82rem',padding:'9px 16px'}} onClick={()=>navigate('/video-studio',{state:{script:cloneOutput}})}>🎬 Video Studio</button>
                  <button className="btn-secondary" style={{fontSize:'0.82rem',padding:'9px 16px'}} onClick={()=>cloneScript(lastType)}>🔄 Regeneriši</button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
