import { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

// ── IndexedDB helper ──────────────────────────────────────────────────────────
let _db = null;
async function getDB() {
  if (_db) return _db;
  return new Promise((res, rej) => {
    const req = indexedDB.open('ShortAILibrary', 1);
    req.onupgradeneeded = e => { if (!e.target.result.objectStoreNames.contains('videos')) e.target.result.createObjectStore('videos', {keyPath:'id'}); };
    req.onsuccess = e => { _db = e.target.result; res(_db); };
    req.onerror = () => rej(req.error);
  });
}
async function dbPut(item) { const db=await getDB(); return new Promise((res,rej)=>{ const tx=db.transaction('videos','readwrite'); tx.objectStore('videos').put(item); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }
async function dbGetAll() { const db=await getDB(); return new Promise((res,rej)=>{ const req=db.transaction('videos','readonly').objectStore('videos').getAll(); req.onsuccess=()=>res(req.result||[]); req.onerror=()=>rej(req.error); }); }
async function dbGet(id) { const db=await getDB(); return new Promise((res,rej)=>{ const req=db.transaction('videos','readonly').objectStore('videos').get(id); req.onsuccess=()=>res(req.result); req.onerror=()=>rej(req.error); }); }
async function dbDelete(id) { const db=await getDB(); return new Promise((res,rej)=>{ const tx=db.transaction('videos','readwrite'); tx.objectStore('videos').delete(id); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }

// ── Canvas drawing ────────────────────────────────────────────────────────────
const THEMES = {
  subtitle: { bg:(ctx,w,h)=>{ const g=ctx.createLinearGradient(0,0,0,h); g.addColorStop(0,'#0a0a1a'); g.addColorStop(1,'#1a0a2e'); ctx.fillStyle=g; ctx.fillRect(0,0,w,h); ctx.strokeStyle='rgba(124,58,237,0.08)'; ctx.lineWidth=1; for(let x=0;x<w;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();} for(let y=0;y<h;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();} }, text:'#fff', accent:'#7c3aed', opacity:0.75 },
  gradient: { bg:(ctx,w,h)=>{ const g=ctx.createLinearGradient(0,0,w,h); g.addColorStop(0,'#7c3aed'); g.addColorStop(0.5,'#06b6d4'); g.addColorStop(1,'#ec4899'); ctx.fillStyle=g; ctx.fillRect(0,0,w,h); }, text:'#fff', accent:'#fff', opacity:0.35 },
  dark:     { bg:(ctx,w,h)=>{ ctx.fillStyle='#000'; ctx.fillRect(0,0,w,h); }, text:'#fff', accent:'#06b6d4', opacity:0 },
  reddit:   { bg:(ctx,w,h)=>{ ctx.fillStyle='#1a1a1b'; ctx.fillRect(0,0,w,h); ctx.fillStyle='#ff4500'; ctx.fillRect(0,0,w,Math.round(h*0.06)); ctx.font=`bold ${Math.round(h*0.035)}px Arial`; ctx.fillText('reddit',Math.round(w*0.04),Math.round(h*0.042)); }, text:'#d7dadc', accent:'#ff4500', opacity:0.6 },
};

function parseScript(text) {
  if (!text.trim()) return [];
  const lines = text.split('\n').map(l=>l.trim()).filter(Boolean);
  const scenes=[]; let cur='';
  for(const line of lines){
    if(/^\[/.test(line)||/^(HOOK|SCENE|NARRATION|CTA|VISUAL|ACT)/i.test(line)){if(cur.trim())scenes.push(cur.trim());cur=line;}
    else{cur+=(cur?' ':'')+line;if(cur.split(' ').length>=15){scenes.push(cur.trim());cur='';}}
  }
  if(cur.trim())scenes.push(cur.trim());
  return scenes.length?scenes:[text.trim()];
}

function drawScene(ctx,text,W,H,theme,sceneIdx,total,fontSize,progress){
  ctx.clearRect(0,0,W,H);
  theme.bg(ctx,W,H);
  ctx.fillStyle=`rgba(0,0,0,${1-theme.opacity})`;ctx.fillRect(0,0,W,H);
  // Progress bar
  ctx.fillStyle='rgba(255,255,255,0.1)';ctx.fillRect(0,H-4,W,4);
  ctx.fillStyle=theme.accent;ctx.fillRect(0,H-4,W*progress,4);
  // Dots
  const dotR=4,sp=dotR*3,tW=total*sp,sX=(W-tW)/2;
  for(let i=0;i<total;i++){ctx.beginPath();ctx.arc(sX+i*sp+dotR,H-20,dotR,0,Math.PI*2);ctx.fillStyle=i===sceneIdx?theme.accent:'rgba(255,255,255,0.25)';ctx.fill();}
  // Text
  const fSize=Math.round(parseInt(fontSize)*(W/540));
  ctx.font=`800 ${fSize}px 'Arial Black',Arial,sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';
  const words=text.replace(/^\[.*?\]\s*/,'').split(' ');
  const lines2=[];let line='';
  for(const w of words){const t=line?line+' '+w:w;if(ctx.measureText(t).width>W*0.85&&line){lines2.push(line);line=w;}else line=t;}
  if(line)lines2.push(line);
  const lH=fSize*1.3,tH=lines2.length*lH,sY=(H-tH)/2;
  lines2.forEach((l,i)=>{const y=sY+i*lH+lH/2;ctx.fillStyle='rgba(0,0,0,0.8)';ctx.fillText(l,W/2+2,y+2);ctx.fillStyle=theme.text;ctx.fillText(l,W/2,y);if(i===lines2.length-1){const tw=ctx.measureText(l).width;ctx.fillStyle=theme.accent;ctx.fillRect(W/2-tw/2,y+fSize*0.6,tw,3);}});
  ctx.font=`600 ${Math.round(fSize*0.4)}px Arial`;ctx.fillStyle='rgba(255,255,255,0.3)';ctx.fillText('⚡ ShortAI',W/2,24);ctx.textAlign='left';
}

function formatSize(b){if(!b)return'0 B';if(b<1024)return b+' B';if(b<1048576)return(b/1024).toFixed(1)+' KB';return(b/1048576).toFixed(1)+' MB';}

// ── Component ─────────────────────────────────────────────────────────────────
export default function VideoStudio({ showToast }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [tab, setTab] = useState('build');
  const [script, setScript] = useState(location.state?.script || '');
  const [style, setStyle] = useState('subtitle');
  const [ratio, setRatio] = useState('9:16');
  const [fontSize, setFontSize] = useState('36');
  const [sceneSecs, setSceneSecs] = useState('3');
  const [building, setBuilding] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressText, setProgressText] = useState('');
  const [scenes, setScenes] = useState([]);
  const [activeScene, setActiveScene] = useState(0);
  const [videoUrl, setVideoUrl] = useState('');
  const [videoBlob, setVideoBlob] = useState(null);
  const [videoName, setVideoName] = useState('');
  const [library, setLibrary] = useState([]);
  const [upTitle, setUpTitle] = useState('');
  const [upDesc, setUpDesc] = useState('');
  const [upPrivacy, setUpPrivacy] = useState('private');
  const canvasRef = useRef();
  const videoRef = useRef();

  useEffect(() => { loadLibrary(); }, []);
  useEffect(() => { if (location.state?.script) setScript(location.state.script); }, [location.state]);

  async function loadLibrary() {
    try { setLibrary(await dbGetAll()); } catch {}
  }

  async function buildVideo() {
    if (!script.trim()) { showToast('Unesi skriptu!','error'); return; }
    const parsed = parseScript(script);
    if (!parsed.length) { showToast('Skripta prazna!','error'); return; }
    setScenes(parsed); setBuilding(true); setProgress(0); setVideoUrl('');

    const dims = ratio==='9:16'?{w:540,h:960}:ratio==='16:9'?{w:960,h:540}:{w:720,h:720};
    const W=dims.w,H=dims.h,theme=THEMES[style]||THEMES.subtitle;
    const fps=30,secPerScene=parseInt(sceneSecs)||3;
    const canvas=canvasRef.current; canvas.width=W; canvas.height=H;
    const ctx=canvas.getContext('2d');
    const mimeType=MediaRecorder.isTypeSupported('video/webm;codecs=vp9')?'video/webm;codecs=vp9':'video/webm';
    const recorder=new MediaRecorder(canvas.captureStream(fps),{mimeType,videoBitsPerSecond:2500000});
    const chunks=[];
    recorder.ondataavailable=e=>{if(e.data.size>0)chunks.push(e.data);};
    recorder.start(100);
    const total=parsed.length*secPerScene*fps;let fi=0;
    for(let s=0;s<parsed.length;s++){
      setProgressText(`Scena ${s+1} od ${parsed.length}...`);
      setProgress(Math.round((s/parsed.length)*85)+5);
      const sf=secPerScene*fps;
      for(let f=0;f<sf;f++){
        const fade=Math.min(fps*0.3,sf/4);
        let alpha=1;if(f<fade)alpha=f/fade;else if(f>sf-fade)alpha=(sf-f)/fade;
        drawScene(ctx,parsed[s],W,H,theme,s,parsed.length,fontSize,fi/total);
        if(alpha<1){ctx.fillStyle=`rgba(0,0,0,${1-alpha})`;ctx.fillRect(0,0,W,H);}
        fi++;if(f%30===0)await new Promise(r=>setTimeout(r,0));
      }
    }
    setProgressText('Finalizam...');
    await new Promise(r=>{recorder.onstop=r;recorder.stop();});
    await new Promise(r=>setTimeout(r,200));
    const blob=new Blob(chunks,{type:mimeType});
    const name=`shortai-${Date.now()}.webm`;
    setVideoBlob(blob); setVideoName(name);
    setVideoUrl(URL.createObjectURL(blob));
    setProgress(100); setBuilding(false);
    showToast(`🎬 Video gotov! ${parsed.length} scena, ${formatSize(blob.size)}`,'success');
  }

  async function saveToLibrary() {
    if (!videoBlob) { showToast('Nema videa','error'); return; }
    try {
      const canvas=document.createElement('canvas');canvas.width=120;canvas.height=214;
      const ctx2=canvas.getContext('2d');if(videoRef.current)ctx2.drawImage(videoRef.current,0,0,120,214);
      const thumb=canvas.toDataURL('image/jpeg',0.6);
      await dbPut({id:'vid_'+Date.now(),name:videoName,blob:videoBlob,thumb,date:new Date().toISOString(),size:videoBlob.size});
      showToast('📁 Sačuvano!','success'); loadLibrary();
    } catch(err){showToast('❌ '+err.message,'error');}
  }

  function downloadVideo() {
    if (!videoBlob) return;
    const a=document.createElement('a');a.href=URL.createObjectURL(videoBlob);a.download=videoName;a.click();
    showToast('📥 Preuzeto!','success');
  }

  async function uploadToYouTube() {
    const token=localStorage.getItem('yt_access_token');
    if(!token){showToast('Povezi YouTube u Platforme tabu!','error');return;}
    if(!videoBlob){showToast('Nema videa za upload!','error');return;}
    showToast('⏳ Uploadujem na YouTube...','info');
    try{
      const init=await fetch('https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',{
        method:'POST',
        headers:{'Authorization':`Bearer ${token}`,'Content-Type':'application/json','X-Upload-Content-Type':videoBlob.type,'X-Upload-Content-Length':videoBlob.size},
        body:JSON.stringify({snippet:{title:upTitle||'ShortAI Video',description:upDesc,categoryId:'22'},status:{privacyStatus:upPrivacy}})
      });
      if(init.status===401){localStorage.removeItem('yt_access_token');throw new Error('Token istekao');}
      if(!init.ok)throw new Error('Init greška '+init.status);
      const uploadUrl=init.headers.get('Location');
      const up=await fetch(uploadUrl,{method:'PUT',headers:{'Content-Type':videoBlob.type,'Content-Length':videoBlob.size},body:videoBlob});
      if(!up.ok)throw new Error('Upload greška '+up.status);
      const data=await up.json();
      showToast('🎉 Uploadovano! ID: '+data.id,'success');
    }catch(err){showToast('❌ '+err.message,'error');}
  }

  function connectYouTube() {
    const clientId=localStorage.getItem('yt_client_id');
    if(!clientId){showToast('Unesi YouTube Client ID!','error');return;}
    const redirectUri=window.location.href.split('?')[0];
    window.open(`https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(clientId)}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=token&scope=${encodeURIComponent('https://www.googleapis.com/auth/youtube.upload')}`,'_blank','width=500,height=600');
  }

  const STYLES = [{val:'subtitle',label:'📺 Tekst + Titlovi'},{val:'gradient',label:'🌈 Gradient'},{val:'dark',label:'🌑 Dark Cinematic'},{val:'reddit',label:'👾 Reddit Style'}];

  return (
    <div>
      <div className="workspace-header">
        <button className="workspace-back" onClick={()=>navigate('/')}>← Nazad</button>
        <div className="workspace-title-row">
          <div className="workspace-icon" style={{background:'linear-gradient(135deg,rgba(124,58,237,0.2),rgba(6,182,212,0.1))'}}>🎬</div>
          <h1 className="workspace-title">Video Studio</h1>
        </div>
        <p className="workspace-desc">Pretvori skriptu u video. Upload na YouTube, TikTok, Instagram.</p>
      </div>

      <div className="tabs">
        {[{id:'build',label:'🔨 Napravi'},{id:'library',label:'📁 Biblioteka'},{id:'upload',label:'🚀 Upload'},{id:'platforms',label:'⚙️ Platforme'}].map(t=>(
          <button key={t.id} className={`tab ${tab===t.id?'active':''}`} onClick={()=>setTab(t.id)}>{t.label}</button>
        ))}
      </div>

      {/* BUILD TAB */}
      {tab==='build' && (
        <div className="two-col">
          <div>
            <div className="form-group">
              <label className="form-label">Stil videa</label>
              <div className="build-opts">
                {STYLES.map(s=><div key={s.val} className={`build-opt ${style===s.val?'active':''}`} onClick={()=>setStyle(s.val)}>{s.label}</div>)}
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Skripta</label>
              <textarea className="form-textarea" style={{minHeight:130}} value={script} onChange={e=>setScript(e.target.value)} placeholder="Zalijepi skriptu... Svaka linija = scena." />
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
              <div className="form-group">
                <label className="form-label">Format</label>
                <select className="form-select" value={ratio} onChange={e=>setRatio(e.target.value)}>
                  <option value="9:16">9:16 TikTok/Reels</option>
                  <option value="16:9">16:9 YouTube</option>
                  <option value="1:1">1:1 Instagram</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Sekundi/sceni</label>
                <select className="form-select" value={sceneSecs} onChange={e=>setSceneSecs(e.target.value)}>
                  {['2','3','4','5'].map(n=><option key={n}>{n}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Veličina fonta</label>
                <select className="form-select" value={fontSize} onChange={e=>setFontSize(e.target.value)}>
                  <option value="28">Mala</option><option value="36">Srednja</option><option value="48">Velika</option><option value="60">Ogromna</option>
                </select>
              </div>
            </div>
            <button className="btn-primary" style={{width:'100%',padding:13}} onClick={buildVideo} disabled={building}>
              {building?'⏳ Generišem...':'🎬 Generiši Video'}
            </button>
          </div>

          <div>
            <p className="form-label" style={{textAlign:'center',marginBottom:10}}>👁️ Preview</p>
            <div className="video-canvas-wrap">
              <canvas ref={canvasRef} style={{display:building&&!videoUrl?'block':'none'}} />
              {!building && !videoUrl && <div style={{textAlign:'center',color:'var(--text-muted)',padding:20}}><div style={{fontSize:'2.5rem',opacity:0.4}}>🎬</div><p style={{fontSize:'0.8rem',marginTop:8}}>Preview ovdje</p></div>}
              {videoUrl && <video ref={videoRef} src={videoUrl} controls autoPlay loop style={{width:'100%',height:'100%',objectFit:'contain'}} />}
              {building && (
                <div className="gen-progress">
                  <div className="spinner"/>
                  <div style={{fontSize:'0.85rem',color:'var(--text-secondary)'}}>{progressText}</div>
                  <div className="gen-progress-bar"><div className="gen-progress-fill" style={{width:progress+'%'}}/></div>
                </div>
              )}
            </div>
            {videoUrl && (
              <div style={{display:'flex',flexDirection:'column',gap:8}}>
                <div style={{display:'flex',gap:8}}>
                  <button className="btn-primary" style={{flex:1,padding:10,fontSize:'0.82rem'}} onClick={downloadVideo}>⬇️ Download</button>
                  <button className="btn-secondary" style={{flex:1,padding:10,fontSize:'0.82rem'}} onClick={saveToLibrary}>📁 Sačuvaj</button>
                </div>
                <button className="btn-secondary" style={{padding:10,fontSize:'0.82rem'}} onClick={()=>setTab('upload')}>🚀 Upload na platforme</button>
              </div>
            )}
            {scenes.length>0 && (
              <div style={{marginTop:16}}>
                <p className="form-label" style={{marginBottom:8}}>🎞️ Scene ({scenes.length})</p>
                <div className="timeline">
                  {scenes.map((s,i)=>(
                    <div key={i} className={`timeline-scene ${i===activeScene?'active':''}`} onClick={()=>setActiveScene(i)}>
                      <div className="ts-num">{i+1}</div>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{fontSize:'0.7rem',fontWeight:700,color:'var(--text-muted)',textTransform:'uppercase'}}>Scena {i+1}</div>
                        <div className="ts-text">{s.replace(/^\[.*?\]\s*/,'')}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* LIBRARY TAB */}
      {tab==='library' && (
        <div>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16,flexWrap:'wrap',gap:10}}>
            <p style={{color:'var(--text-secondary)',fontSize:'0.9rem'}}>Sačuvani videi ({library.length})</p>
            <label className="btn-secondary" style={{padding:'8px 14px',fontSize:'0.82rem',cursor:'pointer'}}>
              📤 Upload sa uređaja
              <input type="file" accept="video/*" style={{display:'none'}} multiple onChange={async e=>{
                for(const f of e.target.files){
                  await dbPut({id:'vid_'+Date.now()+Math.random().toString(36).slice(2),name:f.name,blob:f,thumb:null,date:new Date().toISOString(),size:f.size});
                  showToast(`📁 "${f.name}" uvezen!`,'success');
                }
                loadLibrary();
              }}/>
            </label>
          </div>
          <div className="drop-zone" onDragOver={e=>{e.preventDefault();e.currentTarget.classList.add('drag-over')}} onDragLeave={e=>e.currentTarget.classList.remove('drag-over')} onDrop={async e=>{e.preventDefault();e.currentTarget.classList.remove('drag-over');for(const f of e.dataTransfer.files){if(f.type.startsWith('video/')){await dbPut({id:'vid_'+Date.now(),name:f.name,blob:f,thumb:null,date:new Date().toISOString(),size:f.size});}}loadLibrary();}}>
            <div style={{fontSize:'2rem',marginBottom:8}}>🎞️</div>
            <p style={{fontSize:'0.85rem',color:'var(--text-secondary)'}}>Prevuci video ovdje</p>
          </div>
          <div className="library-grid">
            {!library.length && <div style={{gridColumn:'1/-1',textAlign:'center',padding:40,color:'var(--text-muted)'}}><div style={{fontSize:'2rem',marginBottom:8}}>📭</div><p style={{fontSize:'0.85rem'}}>Biblioteka je prazna.</p></div>}
            {library.map(v=>(
              <div key={v.id} className="library-item" onClick={()=>{ setVideoBlob(v.blob); setVideoName(v.name); setVideoUrl(URL.createObjectURL(v.blob)); setTab('build'); showToast('✅ Video odabran!','success'); }}>
                <div className="library-thumb">{v.thumb?<img src={v.thumb} alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/>:'🎬'}</div>
                <div style={{padding:'6px 8px'}}>
                  <div style={{fontSize:'0.7rem',fontWeight:600,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{v.name}</div>
                  <div style={{fontSize:'0.62rem',color:'var(--text-muted)'}}>{formatSize(v.size)}</div>
                </div>
                <button style={{position:'absolute',top:4,right:4,background:'rgba(0,0,0,0.6)',border:'none',borderRadius:'50%',width:20,height:20,fontSize:'0.7rem',color:'#fff',cursor:'pointer'}}
                  onClick={async e=>{e.stopPropagation();await dbDelete(v.id);loadLibrary();showToast('🗑️ Obrisano','success');}}>✕</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* UPLOAD TAB */}
      {tab==='upload' && (
        <div>
          <div style={{marginBottom:16,background:'rgba(6,182,212,0.06)',border:'1px solid rgba(6,182,212,0.2)',borderRadius:'var(--radius-md)',padding:14,fontSize:'0.85rem',color:'var(--text-secondary)'}}>
            {videoBlob ? <><strong style={{color:'var(--accent-cyan)'}}>📹 Video spreman:</strong> {videoName} · {formatSize(videoBlob.size)}</> : <span>Nema odabranog videa. <button className="btn-ghost" style={{fontSize:'0.82rem'}} onClick={()=>setTab('build')}>Generiši video →</button></span>}
          </div>
          <div className="form-group"><label className="form-label">Naslov</label><input className="form-input" value={upTitle} onChange={e=>setUpTitle(e.target.value)} placeholder="Naslov videa..." /></div>
          <div className="form-group"><label className="form-label">Opis</label><textarea className="form-textarea" style={{minHeight:80}} value={upDesc} onChange={e=>setUpDesc(e.target.value)} placeholder="Opis, hashtags..." /></div>
          <div className="form-group"><label className="form-label">Privatnost (YT)</label><select className="form-select" value={upPrivacy} onChange={e=>setUpPrivacy(e.target.value)}><option value="public">Javno</option><option value="unlisted">Unlisted</option><option value="private">Privatno</option></select></div>
          <p className="form-label" style={{marginBottom:12}}>Odaberi platformu:</p>
          <div className="platform-grid">
            {[
              {id:'yt',icon:'▶️',name:'YouTube',onClick:uploadToYouTube},
              {id:'tt',icon:'🎵',name:'TikTok',onClick:()=>{downloadVideo();setTimeout(()=>window.open('https://www.tiktok.com/upload','_blank'),800);showToast('📥 Preuzeto! TikTok se otvara...','success');}},
              {id:'ig',icon:'📸',name:'Instagram',onClick:()=>{downloadVideo();setTimeout(()=>window.open('https://www.instagram.com/create/story/','_blank'),800);showToast('📥 Preuzeto! Instagram se otvara...','success');}},
              {id:'dl',icon:'⬇️',name:'Download',onClick:downloadVideo},
            ].map(p=>(
              <div key={p.id} className="platform-card" onClick={p.onClick} style={{cursor:'pointer'}}>
                <div style={{fontSize:'2rem',marginBottom:6}}>{p.icon}</div>
                <div style={{fontSize:'0.75rem',fontWeight:700}}>{p.name}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* PLATFORMS TAB */}
      {tab==='platforms' && (
        <div style={{display:'flex',flexDirection:'column',gap:16}}>
          <div className="output-panel">
            <div className="output-header"><div className="output-title">▶️ YouTube OAuth2</div>{localStorage.getItem('yt_access_token')&&<span style={{padding:'3px 10px',borderRadius:'var(--radius-full)',background:'rgba(16,185,129,0.15)',color:'var(--accent-emerald)',fontSize:'0.72rem',fontWeight:700}}>✓ CONNECTED</span>}</div>
            <div className="output-body">
              <p style={{fontSize:'0.85rem',color:'var(--text-secondary)',marginBottom:16,lineHeight:1.6}}>Potreban ti je Google OAuth Client ID.<br/><a href="https://console.cloud.google.com" target="_blank" rel="noreferrer">console.cloud.google.com</a> → APIs & Services → Credentials</p>
              <div className="form-group"><label className="form-label">Google OAuth Client ID</label><input className="form-input" id="yt-client-id-input" defaultValue={localStorage.getItem('yt_client_id')||''} placeholder="123456...apps.googleusercontent.com" /></div>
              <div style={{display:'flex',gap:8}}>
                <button className="btn-secondary" style={{flex:1}} onClick={()=>{const v=document.getElementById('yt-client-id-input').value.trim();if(v){localStorage.setItem('yt_client_id',v);showToast('💾 Sačuvano!','success');}else showToast('Unesi Client ID','error');}}>💾 Sačuvaj</button>
                <button className="btn-primary" style={{flex:1}} onClick={connectYouTube}>🔗 Poveži</button>
              </div>
            </div>
          </div>
          <div className="output-panel">
            <div className="output-header"><div className="output-title">🎵 TikTok & 📸 Instagram</div></div>
            <div className="output-body"><p style={{fontSize:'0.85rem',color:'var(--text-secondary)',lineHeight:1.6}}>TikTok i Instagram API zahtijevaju poslovne naloge. ShortAI preuzima video i otvara upload stranicu — uploaduj ručno. Brzo i besplatno!</p></div>
          </div>
        </div>
      )}
    </div>
  );
}
