export function OutputPanel({ title, content, loading, placeholder, actions }) {
  function copyText() {
    if (content) navigator.clipboard.writeText(content);
  }
  function downloadText() {
    if (!content) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([content], { type: 'text/plain' }));
    a.download = 'shortai-output.txt';
    a.click();
  }

  return (
    <div className="output-panel">
      <div className="output-header">
        <div className="output-title">{title}</div>
        <div className="output-actions">
          {actions}
          <button className="btn-icon" onClick={copyText} title="Kopiraj">📋</button>
          <button className="btn-icon" onClick={downloadText} title="Download">⬇️</button>
        </div>
      </div>
      <div className="output-body">
        {loading && (
          <div className="loading-spinner">
            <div className="spinner" />
            <span>Generišem...</span>
          </div>
        )}
        {!loading && !content && (
          <div className="output-placeholder">
            <div className="placeholder-icon">✨</div>
            <p>{placeholder || 'Klikni Generiši da počneš'}</p>
          </div>
        )}
        {!loading && content && (
          <pre className="output-text">{content}</pre>
        )}
      </div>
    </div>
  );
}
