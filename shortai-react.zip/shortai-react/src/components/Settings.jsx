import { useState } from 'react';
import { PROVIDERS, getSettings, saveSettings } from '../lib/ai';

export function SettingsPanel({ onClose, onSaved }) {
  const [s, setS] = useState(getSettings);

  function handleSave() {
    saveSettings(s);
    onSaved?.();
    onClose();
  }

  const provider = PROVIDERS[s.provider] || PROVIDERS.groq;

  return (
    <div className="settings-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="settings-panel">
        <button className="settings-close" onClick={onClose}>✕</button>
        <h2>⚙️ AI Postavke</h2>

        <div className="form-group">
          <label className="form-label">AI Provider</label>
          <select className="form-select" value={s.provider}
            onChange={e => setS(p => ({ ...p, provider: e.target.value, model: PROVIDERS[e.target.value]?.models[0] || '' }))}>
            {Object.entries(PROVIDERS).map(([k, v]) => (
              <option key={k} value={k}>{v.name}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label className="form-label">Model</label>
          <select className="form-select" value={s.model}
            onChange={e => setS(p => ({ ...p, model: e.target.value }))}>
            {provider.models.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>

        <div className="form-group">
          <label className="form-label">API Ključ</label>
          <input className="form-input" type="password" value={s.apiKey}
            onChange={e => setS(p => ({ ...p, apiKey: e.target.value }))}
            placeholder="Unesi API ključ..." />
          {s.provider === 'groq' && (
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 6 }}>
              Besplatno: <a href="https://console.groq.com" target="_blank" rel="noreferrer">console.groq.com</a>
            </p>
          )}
        </div>

        <button className="btn-primary" style={{ width: '100%' }} onClick={handleSave}>
          💾 Sačuvaj
        </button>
      </div>
    </div>
  );
}

export function SettingsFab({ onClick, hasKey }) {
  return (
    <button className="settings-fab" onClick={onClick} title="AI Postavke">
      ⚙️
      {!hasKey && <span className="settings-fab-badge">!</span>}
      {hasKey && <span className="settings-fab-badge" style={{ background: '#10b981' }}>✓</span>}
    </button>
  );
}
